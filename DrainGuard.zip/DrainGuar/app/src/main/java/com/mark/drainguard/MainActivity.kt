
package com.mark.drainguard

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// COLORS
private val Navy = Color(0xFF10243A)
private val Blue = Color(0xFF2498D5)
private val LightBlue = Color(0xFFE5F3FC)
private val White = Color(0xFFFFFFFF)
private val Background = Color(0xFFF5F8FB)
private val TextDark = Color(0xFF172B40)
private val Green = Color(0xFF23834B)
private val Orange = Color(0xFFB7791F)

// REPORT DATA
data class DrainReport(
    val location: String,
    val description: String,
    val urgency: Int,
    val photo: Bitmap?,
    val status: MutableState<String> = mutableStateOf("Pending")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            DrainGuardApp()
        }
    }
}

@Composable
fun DrainGuardApp() {

    val reports = remember {
        mutableStateListOf<DrainReport>()
    }

    var screen by remember {
        mutableStateOf("Home")
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Navy,
            secondary = Blue,
            background = Background,
            surface = White
        )
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Background
        ) {
            when (screen) {

                "Home" -> HomeScreen(
                    onReport = { screen = "Report" },
                    onFeatures = { screen = "Features" },
                    onAdmin = { screen = "AdminLogin" },
                    onMyReports = { screen = "MyReports" }
                )

                "Features" -> FeaturesScreen(
                    onBack = { screen = "Home" }
                )

                "Report" -> ReportScreen(
                    reports = reports,
                    onBack = { screen = "Home" },
                    onSubmitted = { screen = "MyReports" }
                )

                "MyReports" -> MyReportsScreen(
                    reports = reports,
                    onBack = { screen = "Home" }
                )

                "AdminLogin" -> AdminLoginScreen(
                    onBack = { screen = "Home" },
                    onLogin = { screen = "AdminDashboard" }
                )

                "AdminDashboard" -> AdminDashboardScreen(
                    reports = reports,
                    onLogout = { screen = "Home" }
                )
            }
        }
    }
}

// HEADER
@Composable
fun AppHeader() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Navy)
            .padding(horizontal = 22.dp, vertical = 18.dp)
    ) {
        Text(
            text = "DRAINGUARD",
            color = White,
            fontSize = 23.sp,
            fontWeight = FontWeight.ExtraBold
        )

        Text(
            text = "SMART DRAINAGE MONITORING",
            color = Color(0xFFB9DDF2),
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

// HOME SCREEN
@Composable
fun HomeScreen(
    onReport: () -> Unit,
    onFeatures: () -> Unit,
    onAdmin: () -> Unit,
    onMyReports: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {

        AppHeader()

        Column(
            modifier = Modifier.padding(20.dp)
        ) {

            // HERO SECTION
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Navy
                )
            ) {
                Column(
                    modifier = Modifier.padding(22.dp)
                ) {

                    Text(
                        text = "PROTECTING DUMAGUETE CITY",
                        color = Color(0xFF79CCF5),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(15.dp))

                    Text(
                        text = "A Cleaner City.\nA Safer Future.",
                        color = White,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.ExtraBold,
                        lineHeight = 39.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Help prevent flooding by reporting clogged drainage in your community.",
                        color = Color(0xFFD5E5F1),
                        fontSize = 15.sp,
                        lineHeight = 23.sp
                    )

                    Spacer(modifier = Modifier.height(22.dp))

                    Button(
                        onClick = onReport,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Blue
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            "Report a Problem",
                            color = White,
                            modifier = Modifier.padding(5.dp),
                            fontWeight = FontWeight.Bold
                        )
                    }

                    OutlinedButton(
                        onClick = onFeatures,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = White
                        )
                    ) {
                        Text("Explore Features")
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            Text(
                text = "Why DrainGuard?",
                color = Navy,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(7.dp))

            Text(
                text = "A simple way for residents to report drainage problems and help prevent flooding.",
                color = TextDark,
                fontSize = 14.sp,
                lineHeight = 21.sp
            )

            Spacer(modifier = Modifier.height(15.dp))

            FeatureCard(
                "📍 GPS Location",
                "Identify where clogged drainage problems are located."
            )

            FeatureCard(
                "📷 Photo Evidence",
                "Attach pictures of clogged drainage to support your report."
            )

            FeatureCard(
                "📊 Report Tracking",
                "Follow reports from Pending to In Progress and Resolved."
            )

            FeatureCard(
                "🤝 Community Verification",
                "Allow residents to help confirm reported drainage problems."
            )

            FeatureCard(
                "📸 Before and After Photos",
                "View photos showing the condition of drainage after cleanup."
            )

            Spacer(modifier = Modifier.height(20.dp))

            // MY REPORTS
            Button(
                onClick = onMyReports,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Navy
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("View My Reports", modifier = Modifier.padding(5.dp))
            }

            // ADMIN
            OutlinedButton(
                onClick = onAdmin,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Admin Login", color = Navy)
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "DrainGuard • Dumaguete City",
                modifier = Modifier.align(Alignment.CenterHorizontally),
                color = Color.Gray,
                fontSize = 12.sp
            )
        }
    }
}

// FEATURE CARD
@Composable
fun FeatureCard(
    title: String,
    description: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        shape = RoundedCornerShape(15.dp),
        colors = CardDefaults.cardColors(
            containerColor = White
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 2.dp
        )
    ) {
        Column(
            modifier = Modifier.padding(17.dp)
        ) {
            Text(
                text = title,
                color = Navy,
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp
            )

            Spacer(modifier = Modifier.height(7.dp))

            Text(
                text = description,
                color = TextDark,
                fontSize = 14.sp,
                lineHeight = 21.sp
            )
        }
    }
}

// FEATURES SCREEN
@Composable
fun FeaturesScreen(
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        AppHeader()

        Column(
            modifier = Modifier
                .padding(20.dp)
                .verticalScroll(rememberScrollState())
        ) {

            Text(
                text = "How DrainGuard Works",
                color = Navy,
                fontSize = 27.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "Report drainage problems and help city administrators respond to them.",
                color = TextDark,
                fontSize = 14.sp
            )

            Spacer(modifier = Modifier.height(20.dp))

            FeatureCard(
                "1. Report a Problem",
                "Residents submit a report with its location, description, and photo evidence."
            )

            FeatureCard(
                "2. Review the Report",
                "City administrators review incoming drainage complaints."
            )

            FeatureCard(
                "3. Take Action",
                "Maintenance personnel can address the reported drainage problem."
            )

            FeatureCard(
                "4. Track Progress",
                "Residents can check whether a report is Pending, In Progress, or Resolved."
            )

            FeatureCard(
                "Community Verification",
                "Residents can help confirm if a reported problem still exists."
            )

            FeatureCard(
                "Before and After Photos",
                "Administrators can provide photos after cleanup."
            )

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = onBack,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Navy
                )
            ) {
                Text("Back to Home")
            }
        }
    }
}

// REPORT SCREEN
@Composable
fun ReportScreen(
    reports: SnapshotStateList<DrainReport>,
    onBack: () -> Unit,
    onSubmitted: () -> Unit
) {
    val context = LocalContext.current

    var location by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var urgency by remember { mutableIntStateOf(1) }
    var message by remember { mutableStateOf("") }
    var photo by remember { mutableStateOf<Bitmap?>(null) }

    // GALLERY PICKER
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    photo = BitmapFactory.decodeStream(stream)
                }
                message = ""
            } catch (e: Exception) {
                message = "Unable to load the selected picture."
            }
        }
    }

    // CAMERA
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->
        if (bitmap != null) {
            photo = bitmap
            message = ""
        }
    }

    Column(
        modifier = Modifier.fillMaxSize()
    ) {

        AppHeader()

        Column(
            modifier = Modifier
                .padding(20.dp)
                .verticalScroll(rememberScrollState())
        ) {

            Text(
                text = "Report Clogged Drainage",
                color = Navy,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Provide the details and a picture of the drainage problem.",
                color = TextDark,
                fontSize = 14.sp
            )

            Spacer(modifier = Modifier.height(22.dp))

            // LOCATION
            Text(
                "Location",
                color = Navy,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(7.dp))

            OutlinedTextField(
                value = location,
                onValueChange = { location = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = {
                    Text("Enter street or area in Dumaguete")
                },
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(17.dp))

            // DESCRIPTION
            Text(
                "Description",
                color = Navy,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(7.dp))

            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(125.dp),
                placeholder = {
                    Text("Describe the drainage problem...")
                },
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(18.dp))

            // URGENCY
            Text(
                "Urgency Level",
                color = Navy,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(9.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                (1..4).forEach { level ->
                    Button(
                        onClick = { urgency = level },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (urgency == level) Navy else LightBlue,
                            contentColor = if (urgency == level) White else Navy
                        ),
                        contentPadding = PaddingValues(5.dp)
                    ) {
                        Text(
                            text = level.toString(),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "1 = Low   2 = Moderate   3 = High   4 = Critical",
                color = Color.Gray,
                fontSize = 11.sp
            )

            Spacer(modifier = Modifier.height(22.dp))

            // PHOTO EVIDENCE
            Text(
                text = "Photo Evidence",
                color = Navy,
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp
            )

            Spacer(modifier = Modifier.height(7.dp))

            Text(
                text = "Add a picture so administrators can see the drainage problem.",
                color = TextDark,
                fontSize = 13.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            // PHOTO PREVIEW
            if (photo != null) {

                Image(
                    bitmap = photo!!.asImageBitmap(),
                    contentDescription = "Drainage photo preview",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(210.dp),
                    contentScale = ContentScale.Crop
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedButton(
                    onClick = { photo = null },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        "Remove Photo",
                        color = Color.Red
                    )
                }

            } else {

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(135.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = LightBlue
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(15.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            "📷",
                            fontSize = 30.sp
                        )

                        Text(
                            "No picture selected",
                            color = Navy,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // GALLERY BUTTON
            Button(
                onClick = {
                    galleryLauncher.launch("image/*")
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Navy
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Choose from Gallery")
            }

            // CAMERA BUTTON
            OutlinedButton(
                onClick = {
                    cameraLauncher.launch(null)
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    "Take a Picture",
                    color = Navy
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            if (message.isNotEmpty()) {
                Text(
                    text = message,
                    color = Color.Red,
                    fontSize = 13.sp
                )

                Spacer(modifier = Modifier.height(8.dp))
            }

            // SUBMIT
            Button(
                onClick = {
                    when {
                        location.isBlank() -> {
                            message = "Please enter the location."
                        }

                        description.isBlank() -> {
                            message = "Please enter a description."
                        }

                        photo == null -> {
                            message = "Please add a picture of the drainage."
                        }

                        else -> {
                            reports.add(
                                DrainReport(
                                    location = location,
                                    description = description,
                                    urgency = urgency,
                                    photo = photo
                                )
                            )

                            onSubmitted()
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Navy
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    "Submit Report",
                    modifier = Modifier.padding(6.dp),
                    fontWeight = FontWeight.Bold
                )
            }

            OutlinedButton(
                onClick = onBack,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Cancel", color = Navy)
            }
        }
    }
}

// MY REPORTS SCREEN
@Composable
fun MyReportsScreen(
    reports: List<DrainReport>,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize()
    ) {

        AppHeader()

        Column(
            modifier = Modifier
                .padding(20.dp)
                .verticalScroll(rememberScrollState())
        ) {

            Text(
                text = "My Reports",
                color = Navy,
                fontSize = 27.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "View the drainage problems you have submitted.",
                color = TextDark,
                fontSize = 14.sp
            )

            Spacer(modifier = Modifier.height(15.dp))

            if (reports.isEmpty()) {
                Text(
                    "You haven't submitted any reports yet.",
                    color = Color.Gray
                )
            } else {
                reports.forEachIndexed { index, report ->
                    ReportCard(
                        report = report,
                        number = index + 1
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = onBack,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Navy
                )
            ) {
                Text("Back to Home")
            }
        }
    }
}

// REPORT CARD
@Composable
fun ReportCard(
    report: DrainReport,
    number: Int
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        colors = CardDefaults.cardColors(
            containerColor = White
        ),
        shape = RoundedCornerShape(15.dp),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {

            Text(
                text = "Report #$number",
                color = Navy,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            if (report.photo != null) {
                Image(
                    bitmap = report.photo.asImageBitmap(),
                    contentDescription = "Reported drainage",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(190.dp),
                    contentScale = ContentScale.Crop
                )

                Spacer(modifier = Modifier.height(10.dp))
            }

            Text("Location: ${report.location}")
            Text("Description: ${report.description}")
            Text("Urgency Level: ${report.urgency}")

            Spacer(modifier = Modifier.height(10.dp))

            StatusLabel(report.status.value)
        }
    }
}

// STATUS LABEL
@Composable
fun StatusLabel(status: String) {

    val statusColor = when (status) {
        "Resolved" -> Green
        "In Progress" -> Blue
        else -> Orange
    }

    Text(
        text = "Status: $status",
        color = statusColor,
        fontWeight = FontWeight.Bold,
        fontSize = 14.sp
    )
}

// ADMIN LOGIN
@Composable
fun AdminLoginScreen(
    onBack: () -> Unit,
    onLogin: () -> Unit
) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize()
    ) {

        AppHeader()

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Spacer(modifier = Modifier.height(35.dp))

            Text(
                text = "Admin Login",
                color = Navy,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(7.dp))

            Text(
                "Access the DrainGuard management dashboard.",
                color = TextDark
            )

            Spacer(modifier = Modifier.height(25.dp))

            OutlinedTextField(
                value = username,
                onValueChange = { username = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Username") },
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Password") },
                shape = RoundedCornerShape(12.dp),
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(18.dp))

            if (error.isNotEmpty()) {
                Text(
                    error,
                    color = Color.Red
                )
            }

            Button(
                onClick = {
                    if (username == "admin" && password == "admin123") {
                        onLogin()
                    } else {
                        error = "Incorrect username or password."
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Navy
                )
            ) {
                Text("Login")
            }

            TextButton(onClick = onBack) {
                Text("Back to Home", color = Navy)
            }
        }
    }
}

// ADMIN DASHBOARD
@Composable
fun AdminDashboardScreen(
    reports: SnapshotStateList<DrainReport>,
    onLogout: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize()
    ) {

        AppHeader()

        Column(
            modifier = Modifier
                .padding(18.dp)
                .verticalScroll(rememberScrollState())
        ) {

            Text(
                text = "Admin Dashboard",
                color = Navy,
                fontSize = 27.sp,
                fontWeight = FontWeight.Bold
            )

            Text(
                "Manage drainage reports across Dumaguete City.",
                color = TextDark,
                fontSize = 14.sp
            )

            Spacer(modifier = Modifier.height(18.dp))

            // DASHBOARD COUNTS
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {

                DashboardCount(
                    "Total",
                    reports.size,
                    Modifier.weight(1f)
                )

                DashboardCount(
                    "Pending",
                    reports.count { it.status.value == "Pending" },
                    Modifier.weight(1f)
                )

                DashboardCount(
                    "Resolved",
                    reports.count { it.status.value == "Resolved" },
                    Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(22.dp))

            Text(
                text = "Submitted Reports",
                color = Navy,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(8.dp))

            if (reports.isEmpty()) {

                Text(
                    "No reports have been submitted yet.",
                    color = Color.Gray
                )

            } else {

                reports.forEachIndexed { index, report ->

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = White
                        ),
                        shape = RoundedCornerShape(15.dp),
                        elevation = CardDefaults.cardElevation(2.dp)
                    ) {

                        Column(
                            modifier = Modifier.padding(15.dp)
                        ) {

                            Text(
                                "Report #${index + 1}",
                                color = Navy,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )

                            Spacer(modifier = Modifier.height(9.dp))

                            // SHOW REPORTED PHOTO
                            if (report.photo != null) {
                                Image(
                                    bitmap = report.photo.asImageBitmap(),
                                    contentDescription = "Drainage report photo",
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(190.dp),
                                    contentScale = ContentScale.Crop
                                )

                                Spacer(modifier = Modifier.height(10.dp))
                            }

                            Text("Location: ${report.location}")
                            Text("Description: ${report.description}")
                            Text("Urgency Level: ${report.urgency}")

                            Spacer(modifier = Modifier.height(8.dp))

                            StatusLabel(report.status.value)

                            Spacer(modifier = Modifier.height(12.dp))

                            // UPDATE STATUS
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {

                                Button(
                                    onClick = {
                                        report.status.value = "In Progress"
                                    },
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(5.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Blue
                                    )
                                ) {
                                    Text(
                                        "In Progress",
                                        fontSize = 10.sp
                                    )
                                }

                                Button(
                                    onClick = {
                                        report.status.value = "Resolved"
                                    },
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(5.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Green
                                    )
                                ) {
                                    Text(
                                        "Resolve",
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            TextButton(
                                onClick = {
                                    reports.remove(report)
                                }
                            ) {
                                Text(
                                    "Delete Report",
                                    color = Color.Red
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            OutlinedButton(
                onClick = onLogout,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Logout", color = Navy)
            }
        }
    }
}

// DASHBOARD COUNT CARD
@Composable
fun DashboardCount(
    label: String,
    count: Int,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = LightBlue
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Text(
                text = count.toString(),
                color = Navy,
                fontSize = 23.sp,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = label,
                color = Navy,
                fontSize = 11.sp
            )
        }
    }
}
